from django.apps import AppConfig


class LyceeConfig(AppConfig):
    name = 'lycee'
